import { useRef, useEffect } from "react";

interface Bubble {
  x: number;
  y: number;
  radius: number;
  speed: number;
  wobble: number;
  wobbleSpeed: number;
  wobbleAmp: number;
  opacity: number;
  glow: boolean;
}

export function BubblesCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const bubblesRef = useRef<Bubble[]>([]);
  const animationRef = useRef<number>(0);
  const timeRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resize();
    window.addEventListener("resize", resize);

    // Read accent color from CSS variable
    const getBubbleColor = () => {
      const style = getComputedStyle(document.documentElement);
      const accent = style.getPropertyValue("--accent-blue").trim() || "#3b82f6";
      return accent;
    };

    // Initialize bubbles
    const bubbleCount = 50;
    bubblesRef.current = Array.from({ length: bubbleCount }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      radius: 3 + Math.random() * 12,
      speed: 0.3 + Math.random() * 1.5,
      wobble: Math.random() * Math.PI * 2,
      wobbleSpeed: 0.01 + Math.random() * 0.02,
      wobbleAmp: 10 + Math.random() * 30,
      opacity: 0.05 + Math.random() * 0.2,
      glow: Math.random() > 0.7,
    }));

    const hexToRgb = (hex: string) => {
      const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
      return result
        ? {
            r: parseInt(result[1], 16),
            g: parseInt(result[2], 16),
            b: parseInt(result[3], 16),
          }
        : { r: 59, g: 130, b: 246 };
    };

    const animate = () => {
      timeRef.current += 1;
      const accent = getBubbleColor();
      const rgb = hexToRgb(accent);

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      bubblesRef.current.forEach((bubble) => {
        bubble.y -= bubble.speed;
        bubble.wobble += bubble.wobbleSpeed;

        const wobbleX = Math.sin(bubble.wobble) * bubble.wobbleAmp;
        const drawX = bubble.x + wobbleX;

        if (bubble.y + bubble.radius < 0) {
          bubble.y = canvas.height + bubble.radius;
          bubble.x = Math.random() * canvas.width;
        }

        ctx.save();
        ctx.globalAlpha = bubble.opacity;

        if (bubble.glow) {
          ctx.shadowBlur = 15;
          ctx.shadowColor = `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.4)`;
        }

        const gradient = ctx.createRadialGradient(
          drawX - bubble.radius * 0.3,
          bubble.y - bubble.radius * 0.3,
          0,
          drawX,
          bubble.y,
          bubble.radius
        );
        gradient.addColorStop(0, `rgba(${rgb.r + 60}, ${rgb.g + 40}, ${Math.min(rgb.b + 80, 255)}, 0.3)`);
        gradient.addColorStop(0.5, `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.15)`);
        gradient.addColorStop(1, `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.02)`);

        ctx.beginPath();
        ctx.arc(drawX, bubble.y, bubble.radius, 0, Math.PI * 2);
        ctx.fillStyle = gradient;
        ctx.fill();

        ctx.beginPath();
        ctx.arc(
          drawX - bubble.radius * 0.3,
          bubble.y - bubble.radius * 0.3,
          bubble.radius * 0.25,
          0,
          Math.PI * 2
        );
        ctx.fillStyle = "rgba(255, 255, 255, 0.2)";
        ctx.fill();

        ctx.restore();
      });

      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(animationRef.current);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none"
      style={{ zIndex: 1 }}
    />
  );
}
