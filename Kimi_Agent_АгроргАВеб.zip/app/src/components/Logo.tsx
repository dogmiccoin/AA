import { cn } from "@/lib/utils";

interface LogoProps {
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
}

export function Logo({ size = "md", className }: LogoProps) {
  const sizeClasses = {
    sm: "text-xl tracking-[0.12em]",
    md: "text-[28px] tracking-[0.15em]",
    lg: "text-[48px] tracking-[0.15em]",
    xl: "text-[64px] tracking-[0.15em]",
  };

  return (
    <span
      className={cn(
        "font-display font-normal text-text-primary inline-block",
        sizeClasses[size],
        className
      )}
    >
      <span className="text-glow-white">Агрорг</span>
      <span className="text-[var(--accent-blue)] animate-pulse-blue inline-block">А</span>
    </span>
  );
}
