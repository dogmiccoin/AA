import { Moon, Sun, Clock } from "lucide-react";
import { useTheme } from "@/context/ThemeContext";
import { cn } from "@/lib/utils";

export function ThemeToggle() {
  const { mode, setMode } = useTheme();

  return (
    <div className="flex items-center theme-toggle-wrapper rounded-full p-[3px]">
      <button
        onClick={() => setMode("dark")}
        aria-label="Тёмная тема"
        className={cn(
          "relative flex items-center justify-center w-8 h-8 rounded-full transition-all duration-300",
          mode === "dark"
            ? "theme-toggle-active text-white"
            : "text-text-muted hover:text-text-primary"
        )}
      >
        <Moon className="w-4 h-4" />
      </button>

      <button
        onClick={() => setMode("auto")}
        aria-label="Динамическая тема"
        className={cn(
          "relative flex items-center justify-center w-8 h-8 rounded-full transition-all duration-300",
          mode === "auto"
            ? "theme-toggle-active text-white"
            : "text-text-muted hover:text-text-primary"
        )}
      >
        <Clock className="w-4 h-4" />
      </button>

      <button
        onClick={() => setMode("light")}
        aria-label="Светлая тема"
        className={cn(
          "relative flex items-center justify-center w-8 h-8 rounded-full transition-all duration-300",
          mode === "light"
            ? "theme-toggle-active text-white"
            : "text-text-muted hover:text-text-primary"
        )}
      >
        <Sun className="w-4 h-4" />
      </button>
    </div>
  );
}
