import { createContext, useContext, useState, useEffect, useCallback, useMemo, type ReactNode } from "react";

type ThemeMode = "dark" | "auto" | "light";
type ResolvedTheme = "dawn" | "day" | "sunset" | "night";

interface ThemeContextType {
  mode: ThemeMode;
  resolved: ResolvedTheme;
  setMode: (mode: ThemeMode) => void;
  isDark: boolean;
}

const ThemeContext = createContext<ThemeContextType | null>(null);

function getTimeBasedTheme(): ResolvedTheme {
  const hour = new Date().getHours();
  if (hour >= 5 && hour < 10) return "dawn";
  if (hour >= 10 && hour < 17) return "day";
  if (hour >= 17 && hour < 21) return "sunset";
  return "night";
}

function resolveTheme(mode: ThemeMode): ResolvedTheme {
  if (mode === "dark") return "night";
  if (mode === "light") return "day";
  return getTimeBasedTheme();
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [mode, setModeState] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem("agrorga-theme") as ThemeMode | null;
    return saved && ["dark", "auto", "light"].includes(saved) ? saved : "auto";
  });

  const [resolved, setResolved] = useState<ResolvedTheme>(() => resolveTheme(mode));

  const setMode = useCallback((newMode: ThemeMode) => {
    setModeState(newMode);
    localStorage.setItem("agrorga-theme", newMode);
  }, []);

  useEffect(() => {
    const newResolved = resolveTheme(mode);
    setResolved(newResolved);
    document.documentElement.setAttribute("data-theme", newResolved);
  }, [mode]);

  // Update every minute when in auto mode
  useEffect(() => {
    if (mode !== "auto") return;
    const interval = setInterval(() => {
      const newResolved = getTimeBasedTheme();
      setResolved((prev) => {
        if (prev !== newResolved) {
          document.documentElement.setAttribute("data-theme", newResolved);
        }
        return newResolved;
      });
    }, 60000);
    return () => clearInterval(interval);
  }, [mode]);

  const isDark = useMemo(() => resolved !== "day", [resolved]);

  return (
    <ThemeContext.Provider value={{ mode, resolved, setMode, isDark }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be used within ThemeProvider");
  return ctx;
}
