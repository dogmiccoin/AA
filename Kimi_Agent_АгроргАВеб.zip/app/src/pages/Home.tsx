import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { HeroSection } from "@/sections/HeroSection";
import { AboutSection } from "@/sections/AboutSection";
import { ProductsSection } from "@/sections/ProductsSection";
import { AdvantagesSection } from "@/sections/AdvantagesSection";
import { ContactSection } from "@/sections/ContactSection";

export default function Home() {
  return (
    <div className="min-h-[100dvh] bg-deep">
      <Navbar />
      <main>
        <HeroSection />
        <AboutSection />
        <ProductsSection />
        <AdvantagesSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}
