import { ScrollReveal } from "@/components/ScrollReveal";

const stats = [
  { value: "3+", label: "года на рынке" },
  { value: "100+", label: "видов кормов" },
  { value: "5+", label: "заводов-производителей" },
  { value: "85+", label: "регионов РФ" },
];

const paragraphs = [
  "АгроргА специализируется на импорте и поставке высококачественных кормов для аквакультурной рыбы на территорию Российской Федерации. Мы работаем напрямую с ведущими европейскими и азиатскими производителями, обеспечивая стабильные поставки продукции, отвечающей международным стандартам качества.",
  "Наши корма предназначены для всех стадий выращивания — от личинок до товарной рыбы. Мы предлагаем полный ассортимент: стартовые корма, гранулированные и экструдированные смеси, а также специализированные решения под конкретные виды рыб.",
  "География поставок охватывает все регионы России — от Калининграда до Приморья. Благодаря прямым контрактам с производителями мы гарантируем конкурентные цены и соблюдение сроков доставки.",
];

export function AboutSection() {
  return (
    <section id="about" className="py-20 md:py-32" style={{ backgroundColor: "var(--bg-deep)" }}>
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <ScrollReveal>
          <h2 className="text-3xl md:text-[40px] font-light text-text-primary tracking-tight mb-4">
            О компании АгроргА
          </h2>
        </ScrollReveal>

        <ScrollReveal delay={0.1}>
          <p className="text-base text-text-muted mb-12">
            Надёжный партнёр в сфере аквакультуры
          </p>
        </ScrollReveal>

        {/* Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Left Column — Text */}
          <div>
            {paragraphs.map((text, index) => (
              <ScrollReveal key={index} delay={0.15 * (index + 1)}>
                <p className="text-base text-text-secondary leading-[1.7] mb-8 last:mb-0">
                  {text}
                </p>
              </ScrollReveal>
            ))}
          </div>

          {/* Right Column — Image + Stats */}
          <div className="space-y-8">
            {/* Image */}
            <ScrollReveal delay={0.2}>
              <div className="relative rounded-2xl overflow-hidden">
                <img
                  src="/images/fish-farm.jpg"
                  alt="Рыбное хозяйство"
                  className="w-full h-[220px] object-cover"
                />
                <div
                  className="absolute inset-0"
                  style={{
                    background: `linear-gradient(to top, var(--bg-deep), transparent)`,
                  }}
                />
              </div>
            </ScrollReveal>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 gap-4">
              {stats.map((stat, index) => (
                <ScrollReveal key={stat.label} delay={0.15 * (index + 1)}>
                  <div className="liquid-glass liquid-glass-hover rounded-2xl p-6 text-center transition-all duration-300">
                    <div className="text-3xl md:text-4xl font-semibold text-text-primary mb-1">
                      {stat.value}
                    </div>
                    <div className="text-sm text-text-muted">{stat.label}</div>
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
