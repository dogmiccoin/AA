import {
  Plane,
  FileCheck,
  Truck,
  Wallet,
  Microscope,
  Headphones,
} from "lucide-react";
import { ScrollReveal } from "@/components/ScrollReveal";

const advantages = [
  {
    icon: Plane,
    title: "Прямые поставки",
    description:
      "Работаем без посредников напрямую с заводами-производителями в Европе и Азии",
  },
  {
    icon: FileCheck,
    title: "Сертификация",
    description:
      "Вся продукция имеет необходимые сертификаты соответствия для ввоза в РФ",
  },
  {
    icon: Truck,
    title: "Логистика",
    description:
      "Организуем доставку в любой регион России собственным и партнёрским транспортом",
  },
  {
    icon: Wallet,
    title: "Цены",
    description:
      "Конкурентные цены благодаря прямым контрактам и оптовым объёмам",
  },
  {
    icon: Microscope,
    title: "Консалтинг",
    description:
      "Помощь в подборе кормовых программ под специфику вашего хозяйства",
  },
  {
    icon: Headphones,
    title: "Поддержка 24/7",
    description:
      "Круглосуточная поддержка клиентов на всех этапах сотрудничества",
  },
];

export function AdvantagesSection() {
  return (
    <section id="advantages" className="py-20 md:py-32" style={{ backgroundColor: "var(--bg-deep)" }}>
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <ScrollReveal>
          <h2 className="text-3xl md:text-[40px] font-light text-text-primary tracking-tight mb-4">
            Почему АгроргА
          </h2>
        </ScrollReveal>
        <ScrollReveal delay={0.1}>
          <p className="text-base text-text-muted mb-16">
            Преимущества работы с нами
          </p>
        </ScrollReveal>

        {/* Advantages Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {advantages.map((advantage, index) => {
            const Icon = advantage.icon;
            return (
              <ScrollReveal key={advantage.title} delay={0.12 * (index + 1)} x={-20}>
                <div className="flex items-start gap-5 group">
                  {/* Icon */}
                  <div className="flex-shrink-0 w-11 h-11 rounded-full bg-accent-blue/10 flex items-center justify-center group-hover:bg-accent-blue/20 transition-colors duration-300">
                    <Icon className="w-5 h-5 text-accent-blue" />
                  </div>

                  {/* Content */}
                  <div>
                    <h3 className="text-lg font-medium text-text-primary mb-2">
                      {advantage.title}
                    </h3>
                    <p className="text-sm text-text-secondary leading-relaxed">
                      {advantage.description}
                    </p>
                  </div>
                </div>
              </ScrollReveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
