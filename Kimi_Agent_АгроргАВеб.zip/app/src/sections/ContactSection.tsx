import { useState } from "react";
import { Phone, Mail, MapPin, Clock, Send } from "lucide-react";
import { ScrollReveal } from "@/components/ScrollReveal";

const contacts = [
  {
    icon: Phone,
    label: "Телефон",
    value: "+7 (495) 123-45-67",
    href: "tel:+74951234567",
  },
  {
    icon: Mail,
    label: "Email",
    value: "cpo@agrorga.ru",
    href: "mailto:cpo@agrorga.ru",
  },
  {
    icon: MapPin,
    label: "Адрес",
    value: "г. Москва, Пресненская наб., 12",
    href: "#",
  },
  {
    icon: Clock,
    label: "Режим работы",
    value: "Пн–Пт: 9:00–18:00",
    href: "#",
  },
];

export function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    await new Promise((resolve) => setTimeout(resolve, 1500));

    setIsSubmitting(false);
    setIsSubmitted(true);
    setFormData({ name: "", phone: "", email: "", message: "" });

    setTimeout(() => setIsSubmitted(false), 5000);
  };

  return (
    <section
      id="contacts"
      className="py-20 md:py-32"
      style={{
        background: "linear-gradient(to bottom, var(--bg-gradient-from), var(--bg-gradient-to))",
      }}
    >
      <div className="max-w-[800px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <ScrollReveal>
            <h2 className="text-3xl md:text-[40px] font-light text-text-primary tracking-tight mb-4">
              Свяжитесь с нами
            </h2>
          </ScrollReveal>
          <ScrollReveal delay={0.1}>
            <p className="text-base text-text-muted">
              Готовы обсудить ваши потребности в кормах
            </p>
          </ScrollReveal>
        </div>

        {/* Contact Panel */}
        <ScrollReveal delay={0.2}>
          <div className="liquid-glass rounded-3xl p-8 md:p-12 mb-8">
            {/* Contact Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-10">
              {contacts.map((contact) => {
                const Icon = contact.icon;
                return (
                  <a
                    key={contact.label}
                    href={contact.href}
                    className="flex items-start gap-3 group"
                  >
                    <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-accent-blue/10 flex items-center justify-center">
                      <Icon className="w-5 h-5 text-accent-blue" />
                    </div>
                    <div>
                      <div className="text-xs font-medium text-text-muted uppercase tracking-wider mb-1">
                        {contact.label}
                      </div>
                      <div className="text-base text-text-primary group-hover:text-accent-blue transition-colors duration-200">
                        {contact.value}
                      </div>
                    </div>
                  </a>
                );
              })}
            </div>

            {/* Form */}
            {isSubmitted ? (
              <div className="text-center py-8">
                <div className="w-16 h-16 rounded-full bg-accent-blue/10 flex items-center justify-center mx-auto mb-4">
                  <Send className="w-8 h-8 text-accent-blue" />
                </div>
                <h3 className="text-xl font-medium text-text-primary mb-2">
                  Спасибо!
                </h3>
                <p className="text-text-secondary">
                  Ваша заявка отправлена. Мы свяжемся с вами в ближайшее время.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <input
                    type="text"
                    name="name"
                    placeholder="Имя"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="theme-input w-full rounded-xl px-4 py-3.5 text-text-primary placeholder:text-text-muted focus:outline-none transition-all duration-200"
                  />
                  <input
                    type="tel"
                    name="phone"
                    placeholder="Телефон"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                    className="theme-input w-full rounded-xl px-4 py-3.5 text-text-primary placeholder:text-text-muted focus:outline-none transition-all duration-200"
                  />
                </div>
                <input
                  type="email"
                  name="email"
                  placeholder="Email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="theme-input w-full rounded-xl px-4 py-3.5 text-text-primary placeholder:text-text-muted focus:outline-none transition-all duration-200"
                />
                <textarea
                  name="message"
                  placeholder="Сообщение"
                  value={formData.message}
                  onChange={handleChange}
                  rows={4}
                  className="theme-input w-full rounded-xl px-4 py-3.5 text-text-primary placeholder:text-text-muted focus:outline-none transition-all duration-200 resize-none"
                />
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="gradient-btn w-full text-white font-medium text-base py-4 rounded-xl disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Отправка...
                    </>
                  ) : (
                    "Отправить"
                  )}
                </button>
              </form>
            )}
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
