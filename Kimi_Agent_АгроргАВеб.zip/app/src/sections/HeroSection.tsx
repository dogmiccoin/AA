import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ChevronDown } from "lucide-react";
import { Logo } from "@/components/Logo";
import { BubblesCanvas } from "@/components/BubblesCanvas";

export function HeroSection() {
  const logoRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const tl = gsap.timeline({ defaults: { ease: "power3.out" } });

    tl.fromTo(
      logoRef.current,
      { opacity: 0, scale: 0.8 },
      { opacity: 1, scale: 1, duration: 0.8 }
    )
      .fromTo(
        titleRef.current,
        { opacity: 0, y: 30 },
        { opacity: 1, y: 0, duration: 1 },
        0.3
      )
      .fromTo(
        subtitleRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 0.8 },
        0.5
      )
      .fromTo(
        ctaRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 0.8 },
        0.7
      )
      .fromTo(
        scrollRef.current,
        { opacity: 0 },
        { opacity: 1, duration: 0.5 },
        1
      );

    return () => {
      tl.kill();
    };
  }, []);

  const handleCtaClick = () => {
    const element = document.querySelector("#contacts");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="relative min-h-[100dvh] flex items-center justify-center overflow-hidden">
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: "url(/images/hero-bg.jpg)" }}
      />

      {/* Overlay — theme-aware */}
      <div
        className="absolute inset-0"
        style={{
          background: `linear-gradient(to bottom, var(--overlay-gradient) 0%, var(--overlay-gradient) 40%, var(--bg-deep) 100%)`,
        }}
      />

      {/* Bubbles Canvas */}
      <BubblesCanvas />

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-[800px] mx-auto">
        {/* Logo */}
        <div ref={logoRef} className="mb-6" style={{ opacity: 0 }}>
          <Logo size="xl" className="justify-center" />
        </div>

        {/* Divider */}
        <div
          className="w-[60px] h-[1px] mx-auto mb-8"
          style={{
            background: "linear-gradient(to right, transparent, var(--text-secondary), transparent)",
          }}
        />

        {/* Title */}
        <h1
          ref={titleRef}
          className="font-display text-4xl sm:text-5xl md:text-[64px] text-text-primary leading-tight mb-6"
          style={{ opacity: 0, textShadow: "0 2px 30px rgba(0,0,0,0.5)" }}
        >
          Импортные корма
          <br />
          для аквакультуры
        </h1>

        {/* Subtitle */}
        <p
          ref={subtitleRef}
          className="text-base sm:text-lg text-text-secondary max-w-[600px] mx-auto mb-10 leading-relaxed"
          style={{ opacity: 0 }}
        >
          Прямые поставки высококачественных и доступных кормов для
          рыбоводческих хозяйств по всей территории Российской Федерации
        </p>

        {/* CTA Button */}
        <div ref={ctaRef} style={{ opacity: 0 }}>
          <button
            onClick={handleCtaClick}
            className="gradient-btn text-white font-medium text-base px-10 py-4 rounded-xl inline-block cursor-pointer"
          >
            Оставить заявку
          </button>
        </div>
      </div>

      {/* Scroll indicator */}
      <div
        ref={scrollRef}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 animate-scroll-indicator"
        style={{ opacity: 0 }}
      >
        <ChevronDown className="w-6 h-6 text-text-muted/60" />
      </div>
    </section>
  );
}
