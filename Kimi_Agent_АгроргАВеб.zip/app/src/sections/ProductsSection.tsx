import {
  Droplets,
  Fish,
  TrendingUp,
  Scale,
  Heart,
  ShieldCheck,
} from "lucide-react";
import { ScrollReveal } from "@/components/ScrollReveal";

const products = [
  {
    icon: Droplets,
    title: "Микронные корма",
    description:
      "Ультрамелкодисперсные корма 0,3–1 мм для первых стадий развития личинок и малька, включая микронный гранулянт",
  },
  {
    icon: Fish,
    title: "Стартовые корма",
    description:
      "Высокобелковые корма для личинок и молоди. Гранулометрия 1,2–2 мм, повышенное содержание протеина",
  },
  {
    icon: TrendingUp,
    title: "Корма для подращивания",
    description:
      "Сбалансированные смеси для активного роста и развития молоди",
  },
  {
    icon: Scale,
    title: "Корма для товарной рыбы",
    description:
      "Полнорационные корма для финишного выращивания товарной рыбы",
  },
  {
    icon: Heart,
    title: "Специальные корма маточного стада",
    description:
      "Специализированные кормовые смеси для поддержания продуктивности маточного поголовья",
  },
  {
    icon: ShieldCheck,
    title: 'Сертифицированные ФГБУ «ВГНКИ»',
    description:
      "Продукция, прошедшая государственную сертификацию ФГБУ «Всероссийский государственный научно-контрольный институт»",
  },
];

export function ProductsSection() {
  return (
    <section
      id="products"
      className="py-20 md:py-32"
      style={{
        background: "linear-gradient(to bottom, var(--bg-gradient-from), var(--bg-gradient-via), var(--bg-gradient-to))",
      }}
    >
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <ScrollReveal>
            <h2 className="text-3xl md:text-[40px] font-light text-text-primary tracking-tight mb-4">
              Продукция
            </h2>
          </ScrollReveal>
          <ScrollReveal delay={0.1}>
            <p className="text-base text-text-muted">
              Полный ассортимент кормов для аквакультуры
            </p>
          </ScrollReveal>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product, index) => {
            const Icon = product.icon;
            return (
              <ScrollReveal key={product.title} delay={0.1 * (index + 1)}>
                <div className="group liquid-glass rounded-[20px] p-8 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_12px_40px_rgba(0,0,0,0.2)] h-full">
                  {/* Icon */}
                  <div className="w-12 h-12 rounded-xl bg-accent-blue/10 flex items-center justify-center mb-5 group-hover:bg-accent-blue/20 transition-colors duration-300">
                    <Icon className="w-6 h-6 text-accent-blue" />
                  </div>

                  {/* Title */}
                  <h3 className="text-xl font-medium text-text-primary mb-3">
                    {product.title}
                  </h3>

                  {/* Description */}
                  <p className="text-sm text-text-secondary leading-relaxed">
                    {product.description}
                  </p>
                </div>
              </ScrollReveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
