# АгроргА — Техническая спецификация

## Зависимости

| Пакет | Версия | Назначение |
|-------|--------|------------|
| gsap | ^3.12 | Анимации, ScrollTrigger, Timeline |
| lucide-react | ^0.400 | Иконки (включено в init) |

GSAP нужен для scroll-triggered анимаций и timeline в Hero. Lucide уже в проекте.

## Компоненты

### Layout

| Компонент | Описание | Повторное использование |
|-----------|----------|------------------------|
| `Navbar` | Фиксированная шапка с liquid glass эффектом, логотип, навигация, CTA, мобильное меню | Единственный |
| `Footer` | Футер с логотипом, навигацией, копирайтом | Единственный |

### Sections

| Компонент | Описание |
|-----------|----------|
| `HeroSection` | Полноэкранная секция с canvas-пузырьками, логотипом, заголовком, CTA |
| `AboutSection` | О компании: двухколоночный макет (текст + статистика) |
| `ProductsSection` | Сетка из 6 карточек продукции (3 колонки) |
| `AdvantagesSection` | Сетка из 6 элементов преимуществ (2 колонки) |
| `ContactSection` | Контактная панель + форма обратной связи |

### Переиспользуемые компоненты

| Компонент | Назначение | Где используется |
|-----------|------------|-----------------|
| `LiquidGlassCard` | Карточка с эффектом liquid glass (backdrop-filter, blur, граница) | Products, Advantages, Statistics |
| `Logo` | Текстовый логотип "АгроргА" с glow-эффектом и пульсирующей "А" | Navbar, Hero, Footer |
| `BubblesCanvas` | Canvas 2D с анимированными пузырьками | HeroSection |
| `ScrollReveal` | Обертка для scroll-triggered анимаций через GSAP ScrollTrigger | Все секции |
| `GradientButton` | Кнопка с градиентом и glow-эффектом | Hero, Navbar, Contact |

## Хуки

| Хук | Назначение |
|-----|------------|
| `useScrollPosition` | Отслеживание скролла для изменения navbar (прозрачность, тень) |

## Реализация эффектов

### Liquid Glass (CSS-only)

Реализуется чисто через Tailwind + CSS. Ключевые свойства:
- `backdrop-filter: blur(16px) saturate(180%)`
- Полупрозрачный фон `bg-white/[0.04]`
- Тонкая граница `border-white/[0.08]`
- Внутренняя тень для объёма

### Bubbles Canvas (Canvas 2D)

Кастомный компонент на Canvas 2D (без Three.js):
- requestAnimationFrame цикл
- Массив пузырьков с position, radius, speed, opacity
- Синусоидальное покачивание по X
- Пузырьки пересоздаются снизу при выходе сверху
- Gradient fill с glow (shadowBlur) для некоторых

### Scroll-triggered анимации (GSAP ScrollTrigger)

ScrollReveal обертка:
- IntersectionObserver через GSAP ScrollTrigger
- Анимация: opacity + translateY
- Stagger для групп элементов

### Пульсация логотипа (CSS animation)

CSS @keyframes с изменением text-shadow.

## Состояния

| Компонент | Состояние | Управление |
|-----------|-----------|------------|
| Navbar | transparent / scrolled | useScrollPosition |
| Navbar | mobile menu open/closed | useState |
| Contact form | поля формы | useState |
| Contact form | отправка / success / error | useState |

## Маршрутизация

Одностраничный сайт, без маршрутизации. Якорная навигация по секциям (#about, #products, #advantages, #contacts).

## План реализации

1. **Настройка:** шрифты (Google Fonts), цветовые переменные в Tailwind, глобальные стили
2. **Компоненты:** Logo, LiquidGlassCard, GradientButton, BubblesCanvas, ScrollReveal
3. **Layout:** Navbar (с мобильным меню), Footer
4. **Секции:** Hero → About → Products → Advantages → Contact
5. **Анимации:** GSAP ScrollTrigger для всех секций
6. **Адаптив:** mobile-first, проверка на breakpoints
7. **Полировка:** микровзаимодействия, hover-эффекты
